<?php
    $language = strtolower($_POST['language']);
    $code = $_POST['code'];

    $random = substr(md5(mt_rand()), 0, 7);
    $filePath = "temp/" . $random . "." . $language;
    $programFile = fopen($filePath, "w");
    fwrite($programFile, $code);
    fclose($programFile);

    if($language == "php") {
        $output = shell_exec("A:\All-windows-download-part2\Xampp-download\php\php.exe $filePath 2>&1");
        echo $output;
    }

    else if($language == "python") {
        $output = shell_exec("A:\Windows-Download-Files\Python\python.exe $filePath 2>&1");
        echo $output;
    }

    else if($language == "node") {
        rename($filePath, $filePath.".js");
        $output = shell_exec("A:\Windows-Download-Files\Node-js-download\node.exe $filePath.js 2>&1");
        echo $output;
    }

    else if($language == "c") {
        $outputExe = $random . ".exe";
        shell_exec("gcc $filePath -o $outputExe");
        $output = shell_exec(__DIR__ . "//$outputExe");
        echo $output;
    }

    else if($language == "cpp") {
        $outputExe = $random . ".exe";
        shell_exec("g++ $filePath -o $outputExe");
        $output = shell_exec(__DIR__ . "//$outputExe");
        echo $output;
    }

    else{
        echo "please try again";
    }
?>
