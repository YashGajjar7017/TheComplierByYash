const mainFile = require('../main');
const url = require('url');

const reqUrl = 'http://codingwithyash-backhand.c1.biz/server.xml';
const urlObj = url.parse(reqUrl, true);

console.log(urlObj);

