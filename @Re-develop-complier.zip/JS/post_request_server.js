var http = new XMLHttpRequest();
var params = "text=stuff";
http.open("POST", "http://speedckecker.c1.biz/post_request_server.js", true);

http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
http.setRequestHeader("Content-length", params.length);
http.setRequestHeader("Connection", "close");

alert(http.onreadystatechange);
http.onreadystatechange = function () {
    if (http.readyState == 4 && http.status == 200) {
        alert("You will be using post request server...");
        alert(http.responseText);
    }
}

http.send(params);