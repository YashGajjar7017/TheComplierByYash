API_KEY = "34c8103e63msh909728bfda25be5p1bb0fbjsnd587398101bf"; // PLEASE DON'T SHARE 
// API_KEY = "cc6dcd8390msh2e162a8a61f0938p1a4717jsn3b68ec13545b"; // PLEASE DON'T SHARE 

var language_to_id = {
    "C": 50,
    "C++": 54,
    "Java": 62,
    "Python": 71,
};

function encode(str) {
    return btoa(unescape(encodeURIComponent(str || "")));
}

function decode(bytes) {
    var escaped = escape(atob(bytes || ""));
    try {
        return decodeURIComponent(escaped);
    } catch {
        return unescape(escaped);
    }
}

function errorHandler(jqXHR, textStatus, errorThrown) {
    $("#output").val(`${JSON.stringify(jqXHR, null, 4)}`);
    $("#run").prop("disabled", false);
}

function check(token) {
    $("#output").val($("#output").val() + "\nChecking submission status...");
    $.ajax({
        url: `https://judge0-ce.p.rapidapi.com/submissions/${token}?base64_encoded=true`,
        type: "GET",
        headers: {
            "x-rapidapi-host": "judge0-ce.p.rapidapi.com",
            "x-rapidapi-key": API_KEY
        },
        success: function (data, textStatus, jqXHR) {
            if ([1, 2].includes(data["status"]["id"])) {
                $("#output").val($("#output").val() + "\nStatus: " + data["status"]["description"]);
                setTimeout(function () {
                    check(token)
                }, 1000);
            } else {
                var output = [decode(data["compile_output"]), decode(data["stdout"])].join("\n").trim();
                $("#output").val(output);
                $("#run").prop("disabled", false);
            }
        },
        error: errorHandler
    });
}

function run() {
    $("#run").prop("disabled", true);
    $("#output").val("Creating submission...");
    $.ajax({
        url: "https://judge0-ce.p.rapidapi.com/submissions?base64_encoded=true",
        type: "POST",
        contentType: "application/json",
        headers: {
            "x-rapidapi-host": "judge0-ce.p.rapidapi.com",
            "x-rapidapi-key": API_KEY
        },
        data: JSON.stringify({
            "language_id": language_to_id[$("#lang").val()],
            "source_code": encode($("#source").val()),
            "stdin": encode($("#input").val()),
            "redirect_stderr_to_stdout": true
        }),
        success: function (data, textStatus, jqXHR) {
            $("#output").val($("#output").val() + "\nSubmission created.");
            setTimeout(function () {
                check(data["token"])
            }, 2000);
        },
        error: errorHandler
    });
}

$("body").keydown(function (e) {
    if (e.ctrlKey && e.keyCode == 13) {
        run();
    }
});

$("textarea").keydown(function (e) {
    if (e.keyCode == 9) {
        e.preventDefault();
        var start = this.selectionStart;
        var end = this.selectionEnd;

        var append = "    ";
        $(this).val($(this).val().substring(0, start) + append + $(this).val().substring(end));

        this.selectionStart = this.selectionEnd = start + append.length;
    }
});

// ----------------line-number-code
$("#source").focus();

// text area
var codeEditor = document.getElementById('source');
var lineCounter = document.getElementById('lineCounter');

codeEditor.addEventListener('scroll', () => {
    lineCounter.scrollTop = codeEditor.scrollTop;
    lineCounter.scrollLeft = codeEditor.scrollLeft;
});

codeEditor.addEventListener('keydown', (e) => {
    let {
        keyCode
    } = e;
    let {
        value,
        selectionStart,
        selectionEnd
    } = codeEditor;
    if (keyCode === 9) { // TAB = 9
        e.preventDefault();
        codeEditor.value = value.slice(0, selectionStart) + '\t' + value.slice(selectionEnd);
        codeEditor.setSelectionRange(selectionStart + 2, selectionStart + 2)
    }
});

// ----------lefthand-slide-code--------------
const body = document.querySelector('body'),
    sidebar = body.querySelector('nav'),
    toggle = body.querySelector(".toggle"),
    searchBtn = body.querySelector(".search-box"),
    modeSwitch = body.querySelector(".toggle-switch"),
    modeText = body.querySelector(".mode-text");


toggle.addEventListener("click", () => {
    sidebar.classList.toggle("close");
})

searchBtn.addEventListener("click", () => {
    sidebar.classList.remove("close");
})

modeSwitch.addEventListener("click", () => {
    body.classList.toggle("dark");

    if (body.classList.contains("dark")) {
        modeText.innerText = "Light mode";
    } else {
        modeText.innerText = "Dark mode";

    }
});

// ---------textarea-line-code--------------
var lineCountCache = 0;

function line_counter() {
    var lineCount = codeEditor.value.split('\n').length;
    var outarr = new Array();
    if (lineCountCache != lineCount) {
        for (var x = 0; x < lineCount; x++) {
            outarr[x] = (x + 1) + '.';
        }
        lineCounter.value = outarr.join('\n');
    }
    lineCountCache = lineCount;
}
codeEditor.addEventListener('input', () => {
    line_counter();
});

/* Toggle between adding and removing the "responsive" class to topnav when the user clicks on the icon */
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}

// debug
/* Set the width of the side navigation to 250px and the left margin of the page content to 250px */
function openNav() {
    document.getElementById("mySidenav").style.width = "400px";
    // document.getElementById("main").style.marginLeft = "400px";
}

/* Set the width of the side navigation to 0 and the left margin of the page content to 0 */
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    // document.getElementById("main").style.marginLeft = "0";
}
// =============================================================================================================

// -----------Maintance Calling code --------------
// function maintance() {
//     let maintaince = document.getElementsByClassName('maintance');
//     maintaince.innerHTML = `
//     `;
// }
// ---------------blur page code:----------

window.sessionStorage.clear(); //clear localStorage
window.sessionStorage.clear(); //clear sessionStorage

$(document).ready(function () {
    $('.maintance').hide();
    let maintainceToken = 0;
    let token_back;

    $('.mainbreak').click(function () {
        // confirm password
        const code = prompt("PLEASE ENTER THE SERVER TOKEN:");
        if (code === "yashacker") {
            maintainceToken++;
            sessionStorage.setItem('token_true', 'THENDKFNVSJMDNFIIJDFIMKZDFJIXDFHASUHBBSDHUD');
            // toggale class
            if (maintainceToken === 1 && sessionStorage.getItem('token_true')) {
                $('.home,.close').addClass('backup'), 9000;
                $('.maintance').show();
                if (sessionStorage.getItem('token_true')) {
                    sessionStorage.removeItem('token_true');
                    sessionStorage.setItem('token_false', 'YIEURNSDFHAJKRTHUISRTNALERTKMAKSRLQWOIREKW');
                } else {
                    sessionStorage.getItem('token_false');
                }
            } else {
                alert("Please try again");
            }
        } else {
            maintainceToken = 0;

        }
        // $('.home,.close').fadeTo(1000,0.4);
        // $('.home,.close').css("opacity", "0.5");
    });

    let tokenOff = document.getElementById('turnOff')
    tokenOff.addEventListener('click', function () {
        // token_true
        if (sessionStorage.getItem('token_true')) {
            sessionStorage.getItem('token_false');
        } else {
            alert("ckeck the sessionStorage : token_true");
        }

        // token_false
        if (sessionStorage.getItem('token_false')) {
            $('.home,.close').removeClass('backup'), 9000;
            $('.maintance').hide();
        } else {
            console.log('data not found!')
        }
    });

    $('.mainbreak').dblclick(function () {
        $('.maintance').hide();
    });

    // $('a[class="mainbreak"]').attr('disabled', true);  ->Set attribute to a class vai jqueary
});


// -----------stop function----------------
function Stop() {
    document.getElementById('output').innerText = 'program has been stopped...';
    location.reload();
}

// -----------function : Language selector return-------
// Turn io on :-
function turnIOOn() {
    let input = document.getElementById("code_input");
    input.parentNode.removeChild(code_input);

    let output = document.getElementById("code_output");
    output.parentNode.removeChild(code_output);

    let source = document.getElementById('source');
    source.style.height = '80vh';

    let lineCounter = document.getElementById('lineCounter');
    lineCounter.style.height = '80vh';
};

// Turn io off :-
function turnIOOff() {
    let input = document.getElementById("code_input");
    input.parentNode.appendChild(code_input);

    let output = document.getElementById("code_output");
    output.parentNode.appendChild(code_output);

    let mainFooter = document.getElementById('mainFooter');
    mainFooter.parentNode.appendChild(mainFooter);

    let source = document.getElementById('source');
    source.style.height = '43vh';

    let lineCounter = document.getElementById('lineCounter');
    lineCounter.style.height = '43vh';
}

// Language selector code : -

function LangSelector() {

    const language_id = document.getElementById('lang');
    let returnback = language_id.value;

    // -------Language selector-------
    try {
        if (returnback == 'select') {
            window.sessionStorage.setItem('nullId', '0i0c');
        } else if (returnback == 'C') {
            window.sessionStorage.setItem('idBack', '2i2c');
            // code input
            let source = document.getElementById('source');
            source.innerHTML = `#include<stdio.h>
#include<malloc.h>

void main()
{
    printf("Hello world...");
}`;
        } else if ((returnback == 'Cpp')) {
            window.sessionStorage.setItem('idBack', '2i2c');
            console.log('Cpp');
            // code input
            let source = document.getElementById('source');
            source.innerHTML = `#include<iostream.h>
void main()
{
    cout>>'Hello World...';
}`;
        } else if ((returnback == 'Python')) {
            window.sessionStorage.setItem('idBack', '2i2c');
            console.log('python');
            // code input
            let source = document.getElementById('source');
            source.innerText = `print('Hello World')`;

        } else if ((returnback == 'Java')) {
            window.sessionStorage.setItem('idBack', '2i2c');
            console.log('Java');
            // code input
            let source = document.getElementById('source');
            source.innerHTML = `public class Main
{
    public static void main(String[] args)
    {
         System.out.println("Hello World");
    }
}`;
        } else if (returnback === 'Html') {
            window.sessionStorage.setItem('idTake', '1i1c');
            console.log('Html');
            let buttonChange = document.getElementById("mainButton");
            buttonChange.innerText = 'Preview';

            // source.session.setMode("/lib/worker-html.js");
            // code input
            let source = document.getElementById('source');
            source.innerHTML = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HTML 5 Boilerplate</title>
    <link rel ="stylesheet" href ="style.css">
</head>
<body>

    <script src="index.js"></script>
</body>
</html>`;
        } else if ((returnback === 'Css')) {
            window.sessionStorage.setItem('idTake', '1i1c');
            console.log('Css');
            // code input
            let source = document.getElementById('source');
            source.innerHTML = `
/*Use '.' for class & '#' for Id*/
.ClassName{
    margin: 0px;
    padding: 0px
}`;
        } else if ((returnback === 'JS')) {
            window.sessionStorage.setItem('idTake', '1i1c');
            console.log('Js');
            // code input
            let source = document.getElementById('source');
            source.innerHTML = `
let example = document.getElementById('example');
example.addEventListener('click', function (){
    alert('You click on main button');
})`;
            exit;
        } else {
            window.sessionStorage.setItem('nullId', '0i0c');
            console.log('Sorry !your request is not fetch from server');
        }

    } catch (error) {
        console.warn(error);
    }


    // --------Changing layout-----------
    try {
        if (sessionStorage.getItem('idTake')) {
            turnIOOn();
            if (returnback == 'c') {
                turnIOOff();
            }
        } else if (sessionStorage.getItem('idBack')) {
            turnIOOff();
            if (returnback == 'html') {
                turnIOOn();
            }
        } else if (sessionStorage.getItem('nullId')) {
            console.log('unable to load languages in sessionStorage');
        } else {
            console.log('Your option is not valid..!');
        }
    } catch (error) {
        console.log(error);
    }
}

// Fetching data from files:
function upload() {

    const fileSelector = document.getElementById('myFile');
    fileSelector.addEventListener('change', (event) => {
        // const fileList = event.target.files;
        // console.log(fileList);
        // -new update
        function getData() {
            console.log("Started getData function...");
            let url = event.target.textContent;
            // fetch api returns a promise
            fetch(url).then((response) => { //method : async
                console.log("Inside first then of function");
                return response.text(); //this one is a promise
            }).then((data) => {
                console.log("Inside second then of function");
                console.log(data);
            })
        };
        getData();
    });
}

// -----------toggle class maintaince-break timer------------------
function myTimer() {
    // -timer code start
    const countToDate = new Date().setHours(new Date().getHours() + 24)
    let previousTimeBetweenDates
    setInterval(() => {
        const currentDate = new Date()
        const timeBetweenDates = Math.ceil((countToDate - currentDate) / 1000)
        flipAllCards(timeBetweenDates)

        previousTimeBetweenDates = timeBetweenDates
    }, 250)

    function flipAllCards(time) {
        const seconds = time % 60
        const minutes = Math.floor(time / 60) % 60
        const hours = Math.floor(time / 3600)

        flip(document.querySelector("[data-hours-tens]"), Math.floor(hours / 10))
        flip(document.querySelector("[data-hours-ones]"), hours % 10)
        flip(document.querySelector("[data-minutes-tens]"), Math.floor(minutes / 10))
        flip(document.querySelector("[data-minutes-ones]"), minutes % 10)
        flip(document.querySelector("[data-seconds-tens]"), Math.floor(seconds / 10))
        flip(document.querySelector("[data-seconds-ones]"), seconds % 10)
    }

    function flip(flipCard, newNumber) {
        const topHalf = flipCard.querySelector(".top")
        const startNumber = parseInt(topHalf.textContent)
        if (newNumber === startNumber) return

        const bottomHalf = flipCard.querySelector(".bottom")
        const topFlip = document.createElement("div")
        topFlip.classList.add("top-flip")
        const bottomFlip = document.createElement("div")
        bottomFlip.classList.add("bottom-flip")

        top.textContent = startNumber
        bottomHalf.textContent = startNumber
        topFlip.textContent = startNumber
        bottomFlip.textContent = newNumber

        topFlip.addEventListener("animationstart", e => {
            topHalf.textContent = newNumber
        })
        topFlip.addEventListener("animationend", e => {
            topFlip.remove()
        })
        bottomFlip.addEventListener("animationend", e => {
            bottomHalf.textContent = newNumber
            bottomFlip.remove()
        })
        flipCard.append(topFlip, bottomFlip)
    }
    // -timer code end
}

// --------------------------Other code-----------------------------
// let editor;

// window.onload = function() {
//     // editor = ace.edit("editor");
//     // editor.setTheme("ace/theme/monokai");
//     editor.session.setMode("ace/mode/c_cpp");
// }

//     let language = $("#languages").val();

//     if(language == 'c' || language == 'cpp')editor.session.setMode("ace/mode/c_cpp");
//     else if(language == 'Html')editor.session.setMode("/ui/js/lib/worker-html.js");
//     else if(language == 'CSS')editor.session.setMode("ace/mode/css");
//     else if(language == 'php')editor.session.setMode("ace/mode/php");
//     else if(language == 'python')editor.session.setMode("ace/mode/python");
//     else if(language == 'node')editor.session.setMode("ace/mode/javascript");


// ----------request-handler:- ----------
// var server = http.createServer(function (request, response) {
//     var queryData = url.parse(request.url, true).query;

//     if (queryData.text) {
//         convert('engfemale1', queryData.text, response);
//         response.writeHead(200, {
//             'Content-Type': 'audio/mp3',
//             'Content-Disposition': 'attachment; filename="tts.mp3"'
//         });
//     } else {
//         response.end('No text to convert.');
//     }
// }).listen(8080);

// server : https://stackoverflow.com/questions/12006417/node-js-server-that-accepts-post-requests#:~:text=POST%20request%20(web%20browser),Content%2Dlength%22%2C%20params.