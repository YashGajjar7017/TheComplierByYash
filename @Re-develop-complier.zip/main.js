// -------Import contains only -----------
const fs = require('fs');
const http = require('http');
const url = require('url');
// const jsFile = require ('./JS/index');
/*We are using ES6 classes.. so,please don't change the code to CJS modules...*/

// -------------------server handler------------------------
const port = process.env.PORT || 8000; //Actually you don't calling server response so, to bypass this method ,use 8000 port for now   

const server = http.createServer((request, response) => {
    response.statusCode = 200; //sending & ckecking code
    response.setHeader('Content-Type', 'text/html'); //hosting content type

    // console.log(request); //when you hit the server, it will note all responses 
    // console.log(request.url) //This will return your link with you inputData

    if (request.url == '/') {
        response.statusCode = 200;
        const data = fs.readFile('index.html');
        response.end(data.toString());
    } else if (request.url == '/aboutDocs') {
        response.statusCode = 200;
        response.end('<center><h2>updated new aboutDocs of node.js tuturial</h2></center>');
    } else if (request.url == '/updatedPage') {
        response.statusCode = 200;
        response.end('<center><h2>Welcome to node.js tuturial</h2></center>');
    } else {
        response.statusCode = 404;
        response.end('<center><h2 style:"height:50%;">Cool! This is perfect time to start maintance</h2></center>');
    }

});

// server is listenning below syntax :
server.listen(port, () => {
    console.log(`Server is listening on port 127.0.0.1:${port}`);
});

//---------- start server as localhost for html code runner:--------
function htmlReader() {
    const hostname = '127.0.0.1';
    const mainPort = 3000;

    const serverResponse = http.createServer((req, res) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'text/plain');
        res.end('Hello, World!\n');
    });

    serverResponse.listen(mainPort, hostname, () => {
        console.log(`Server running at http://${hostname}:${mainPort}/`);
    });

}

// -----------Reading code source-----------

//To read file :
fs.readFile('./temp/text.c', 'utf8', (err, data) => {
    if (err) {
        console.log(err);
        return;
    }
    console.log(data);
});

// to write-in file:
const content = 'input_source...'
fs.writeFileSync('./temp/text.c', content, err => {
    if (err) {
        console.err;
        return;
    }
});
