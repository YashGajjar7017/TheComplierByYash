const http = require('http');

const { Url } = require("url");

const server = http.createServer((req, res) => {
    res.end("Hello from server");
});

const localhost = "127.0.0.1";
const port = 8000;
server.listen(port, localhost, () => {
    console.log(`Listening on port no. ${localhost}:${port}`);
});

let loader = Url('http://192.168.0.105/Server_Handle/server.js').value;
